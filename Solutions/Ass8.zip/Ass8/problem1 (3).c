
/*
AUTHOR: Rahul Teja Gorantala, Gourav Singla
FILENAME: problem1.c
SPECIFICATION: To create a graph with given input and print the nodes in order.
FOR: CS 5401 Data Structures Section 501
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NODES 6
#define MAXSIZE 100

struct queue {
    int items[MAXSIZE];
    int front;
    int rear;
};
struct queue* createQueue();
struct Node
{
    char val[128];
    int weight;
    int vertex;
    struct Node *next;
} ;

struct AdjList
{
    struct Node *head;
} ;

struct Graph
{
    int* visited;
    struct AdjList *array;
};
struct Node* addNewNode(char vertex[128], int weight, int pos);
void addEdge(struct Graph* graph, char src[0], char dest[0], int weight, int src_pos, int dest_pos, bool undirected);
struct Graph* makeGraph(int V);
void printGraph(struct Graph* graph, char full_string[128], int count);
struct queue* createQueue();
int isEmpty(struct queue* q);
void enqueue(struct queue* q, int value);
int dequeue(struct queue* q);
void bfs(struct Graph* graph, int startVertex, char str[128]);
void bfs_search_helper(struct Graph* graph, char vertex, char str[128]);

/* NAME: addNewNode
PARAMETERS: char vertex to be added, weight of edge, position
PURPOSE: This function adds new node with data.
POSTCONDITION: NA.
*/

struct Node* addNewNode(char vertex[128], int weight, int pos)
{
    struct Node* newNode = (struct Node*) malloc(sizeof(struct Node));
    strcpy(newNode->val,vertex);
    newNode->next = NULL;
    newNode->weight = weight;
    newNode->vertex = pos;
    return newNode;
}


/* NAME: makeGraph
PARAMETERS: char vertex to be added, weight of edge, position
PURPOSE: This function adds new node with data.
POSTCONDITION: NA.
*/

struct Graph* makeGraph(int V)
{
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList));
    graph->visited = (int*)malloc(V * sizeof(int));
    int i;
    for (i = 0; i < V; ++i) {
        graph->array[i].head = NULL;
        graph->visited[i] = 0;
    }

    return graph;
}


/* NAME: addEdge
PARAMETERS: struct graph, char source vertex, char destination vertex, int weight, source vertex position, destination vertex position, boolean
PURPOSE: This function adds new edge.
POSTCONDITION: NA.
*/

void addEdge(struct Graph* graph, char src[0], char dest[0], int weight, int src_pos, int dest_pos, bool undirected)
{
    struct Node* check = NULL;
    struct Node* newNode = addNewNode(dest, weight, dest_pos);

    if (graph->array[src_pos].head == NULL) {
        newNode->next = graph->array[src_pos].head;
        graph->array[src_pos].head = newNode;
    }
    else {

        check = graph->array[src_pos].head;
        while (check->next != NULL) {
            check = check->next;
        }
        check->next = newNode;
    }
    if (undirected){
        newNode = addNewNode(src, weight, src_pos);
        if (graph->array[dest_pos].head == NULL) {
            newNode->next = graph->array[dest_pos].head;
            graph->array[dest_pos].head = newNode;
        }
        else {
            check = graph->array[dest_pos].head;
            while (check->next != NULL) {
                check = check->next;
            }
            check->next = newNode;
        }
    }

}


/* NAME: printGraph
PARAMETERS: struct graph, char all characters, line number
PURPOSE: This function prints the graph.
POSTCONDITION: NA.
*/

void printGraph(struct Graph* graph, char full_string[128], int count)
{
    int v;
    printf("\nAdjacency list:");
    printf("\n No Of Vertices: %i", count);
    printf("\n");
    for (v = 0; v < count; ++v) {
        struct Node* pCrawl = graph->array[v].head;
        printf(" %c ", full_string[v]);
        while (pCrawl) {
            char *ptr = pCrawl->val;
            printf("-> (%c, %i) ", *ptr, pCrawl->weight);
            pCrawl = pCrawl->next;
        }
        printf("-> (nil)");
        printf("\n");
    }
}

/* NAME: createQueue
PARAMETERS: n/a
PURPOSE: This function creates new queue.
POSTCONDITION: NA.
*/

struct queue* createQueue() {
    struct queue* q = malloc(sizeof(struct queue));
    q->front = -1;
    q->rear = -1;
    return q;
}

/* NAME: isEmpty
PARAMETERS: struct queue
PURPOSE: This function check if queue is empty.
POSTCONDITION: NA.
*/


int isEmpty(struct queue* q) {
    if (q->rear == -1)
        return 1;
    else
        return 0;
}

/* NAME: enqueue
PARAMETERS: struct queue, integer value
PURPOSE: This function add new value in queue.
POSTCONDITION: NA.
*/
void enqueue(struct queue* q, int value) {
    if (q->rear == MAXSIZE - 1)
        printf("\nQueue is Full!!");
    else {
        if (q->front == -1)
            q->front = 0;
        q->rear++;
        q->items[q->rear] = value;
    }
}

/* NAME: denqueue
PARAMETERS: struct queue
PURPOSE: This function delete the element from queue.
POSTCONDITION: NA.
*/

int dequeue(struct queue* q) {
    int item;
    if (isEmpty(q)) {
        printf("Queue is empty");
        item = -1;
    } else {
        item = q->items[q->front];
        q->front++;
        if (q->front > q->rear) {
            q->front = q->rear = -1;
        }
    }
    return item;
}

/* NAME: bfs
PARAMETERS: struct queue, starting vertex index, char string
PURPOSE: This function travaser the graph. Its breadth-first search implemementation.
POSTCONDITION: NA.
*/

void bfs(struct Graph* graph, int startVertex, char str[128]) {
    char Queue[128] = "", O[128] = "";
    struct queue* q = createQueue();

    graph->visited[startVertex] = 1;
    enqueue(q, startVertex);

    while (!isEmpty(q)) {
        int currentVertex = dequeue(q);
        strncat(Queue,&str[currentVertex],1);
        strncat(Queue," ",1);


        struct Node* temp = graph->array[currentVertex].head;

        while (temp) {
            int adjVertex = temp->vertex;
            if (graph->visited[adjVertex] == 0) {
                graph->visited[adjVertex] = 1;
                strncat(O," ",1);
                strncat(O,&str[currentVertex],1);
                enqueue(q, adjVertex);
            }
            temp = temp->next;
        }
    }
    printf("\n");
    printf("Q: %s\n", Queue);
    printf("O:  %s", O);
}


/* NAME: bfs_search_helper
PARAMETERS: struct queue, char vertex , char string
PURPOSE: This function is helper function of bfs.
POSTCONDITION: NA.
*/

void bfs_search_helper(struct Graph* graph, char vertex, char str[128]){
    char *position_ptr2 = strchr(str, vertex);
    int position2 = position_ptr2 == NULL ? -1 : position_ptr2 - str;
    bfs(graph, position2, str);
}


int main(void)
{
    FILE *graphFile;
    graphFile = fopen("undirected_text.txt", "r");
    char scan_word[128];
    int n = 0,count = 0,maxNodes=0;
    struct Graph* graph;
    char weight[8],valOne[8],valTwo[8];
    int z = 0;
    int current = 0, current2 = 0;
    bool First = true, undirected = true;
    char full_string[128] = "", Start_vert;
    if(graphFile == NULL){
        printf("File Not Found");
        return 0;
    }
    while (fscanf(graphFile, "%s", scan_word) != EOF)
    {
        n++;
        if(n==1)
            maxNodes = atoi(scan_word);
        if(n==2){
            if (atoi(scan_word) == 1)
                undirected = false;
        }

        if(n>2 && n<maxNodes+3){
            if (First){
                graph = makeGraph(maxNodes);
                First = false;
            }
            count++;
        }
        if (n > MAX_NODES + 2)
        {
            z++;
            if (z == 1)
                strcpy(valOne, scan_word);
            else if (z == 2)
                strcpy(valTwo, scan_word);
            else if (z == 3){
                char *position_ptr = strchr(full_string, valOne[0]);
                int position = position_ptr == NULL ? -1 : position_ptr - full_string;
                if(position == -1){
                    strncat(full_string, valOne, 1);
                    current = strlen(full_string) - 1;
                }
                else
                    current = position;

                char *position_ptr2 = strchr(full_string, valTwo[0]);
                int position2 = position_ptr2 == NULL ? -1 : position_ptr2 - full_string;
                if(position2 == -1){
                    strncat(full_string, valTwo, 1);
                    current2 = strlen(full_string) - 1;
                }
                else
                    current2 = position2;

                z = 0;
                strcpy(weight, scan_word);
                addEdge(graph,valOne,valTwo,atoi(weight),current, current2, undirected);
            }
        }
    }
    printGraph(graph, full_string, count);
    Start_vert = 'C';
    bfs_search_helper(graph, Start_vert, full_string);
    return 0;
}

/*
g) i.

Rahul Teja Gorantala(rgoranta@ttu.edu)
 ---------------------------
   struct Graph* makeGraph(int)                                                          - modified
   void addEdge(struct, char , char, int , int , int , bool )                            - designed/implemented/modified
   int main()                                                                            - designed/implemented/modified
   struct queue* createQueue()                                                           - designed/implemented/modified
   int dequeue(struct queue* q)                                                          - designed/implemented/modified
   void bfs(struc,int,char)                                                              - designed/implemented/modified
   void bfs_search_helper(struct, char , char)                                           - designed/implemented/modified



Gourav Singla(gsingla@ttu.edu)
  --------------------------
  struct Node* addNewNode(char, int , int)                                               - designed/implemented/modified
  struct Graph* makeGraph(int)                                                           - designed/implemented
  void printGraph(struct, char, int)                                                     - designed/implemented/modified
  int main()                                                                             - modified
  int dequeue(struct)                                                                    - designed/implemented/modified
  void bfs(struc,int,char)                                                               - modified
  created 1.txt, 2.txt, 4.txt


g)  ii.
        1. Undirected graph file                                        passed
        2. directed graph file                                          passed


 g) iii. 1. O(V+E)
         2. O(V+E)
         3. O(V+E)

 */

