import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.offline as py
import plotly.graph_objs as go
import plotly.tools as tls
import plotly.express as px
import numpy as np
from sklearn.linear_model import LogisticRegression
from wordcloud import WordCloud, STOPWORDS
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
py.init_notebook_mode(connected=True)
color = sns.color_palette()
%matplotlib inline

# --------------- To Make Histogram ----------------------------

dataframe = pd.read_csv("Reviews.csv")

fig = px.histogram(dataframe,x="Score")
fig.update_traces(marker_color="turquoise",marker_line_color = 'rgb(8,48,107)',marker_line_width=1.5)
fig.update_layout(title_text='product score')
fig.show()
fig.write_image("assignment_3_product_scores.png")

# -------------- To Create Word Clouds------------------------

dataframe = dataframe[dataframe['Score']!=3]
dataframe['sentiment'] = dataframe['Score'].apply(lambda rating : +1 if rating>3 else -1 )
positive = dataframe[dataframe['sentiment']==1]
negative = dataframe[dataframe['sentiment']==-1]
stopwords = set(STOPWORDS)
stopwords.update(["br","href","good","great","buy","flavor","product"])
pos = " ".join(review for review in positive.Summary )
neg = " ".join([str(i) for i in negative.Summary])
wordcloud2 = WordCloud(stopwords=stopwords).generate(pos)
wordcloud3 = WordCloud(stopwords=stopwords).generate(neg)
plt.imshow(wordcloud2,interpolation = 'bilinear')
plt.axis("off")
plt.savefig("assignment_3_wordcloud_pos.png")
plt.show()
plt.imshow(wordcloud3,interpolation='bilinear')
plt.savefig("assignment_3_wordcloud_neg.png")
plt.axis("off")
plt.show()


# --------------------- To Make Prediction ---------------------

def remove_punctuation(text):
    removeSet = ("?",".",";",":","!",'""')
    final = "".join(u for u in text if u not in removeSet)
    return final
dataframe["Text"] = dataframe["Text"].apply(remove_punctuation)
dataframe = dataframe.dropna(subset=['Summary'])
dataframe['Summary'] = dataframe['Summary'].apply(remove_punctuation)
dataframeNew = dataframe[['Summary','sentiment']]
dataframeNew.head()
index = dataframe.index
dataframe['random_number'] = np.random.randn(len(index))
train = dataframe[dataframe['random_number']<=0.7]
test = dataframe[dataframe['random_number']>.7]

vectorizer = CountVectorizer(token_pattern=r'\b\w+\b')
train_matrix = vectorizer.fit_transform(train['Summary'])
test_matrix = vectorizer.transform(test['Summary'])

logistic_regression = LogisticRegression()
X_train = train_matrix
X_test = test_matrix
Y_train = train['sentiment']
Y_test = test['sentiment']
logistic_regression.fit(X_test,Y_test)
predictions  = logistic_regression.predict(test_matrix)

new  = np.asarray(Y_test)

print(confusion_matrix(predictions,Y_test))
print(classification_report(predictions,Y_test))