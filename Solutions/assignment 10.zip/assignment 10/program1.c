/*
AUTHOR: Gourav Singla , Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: Implement generic selection sort, generic quick sort, a generic linear search,
and a generic binary search
FOR: CS 5401 Data Structures Section 501
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_ARR  1000
void main(){
    int arr[MAX_ARR];
    int i;
    int start_element;
    int last_element;
    int mid_element;
    double total_exec_time = 0.0;
    srand(1000);

    for(i=0;i<MAX_ARR;i++){
        arr[i]= (rand()% (MAX_ARR - 100) +10);
    }

    printf("Array of Random Numbers of size %d \n",MAX_ARR);

    // SELECTION SORT
    clock_t selection_begin = clock();
    selection_sort(arr, MAX_ARR,0);
    clock_t selection_end = clock();
    total_exec_time += (double)(selection_end - selection_begin) / CLOCKS_PER_SEC;
    printf("Selection sort...  \n");
    printf("main - sort took %f: seconds \n\n\n",total_exec_time);
  
   


   // QUICK SORT
   for(i=0;i<MAX_ARR;i++){
        arr[i]=(rand()%51);
    }
 
    clock_t quick_begin = clock();
    quick_sort(arr,0,MAX_ARR-1);
    clock_t quick_end = clock();
    total_exec_time += (double)(quick_end - quick_begin) / CLOCKS_PER_SEC;
    printf("QUICK sort...  \n");
    printf("main - sort took %f: seconds \n\n\n",total_exec_time);
 
  //LINEAR SEARCH
  start_element = arr[1];
  last_element = arr[MAX_ARR-1];
  mid_element = arr[MAX_ARR/2];
  clock_t linear_begin = clock();

  int idx = linear_search(arr,last_element);
 
  clock_t linear_end = clock();
   total_exec_time += (double)(quick_end - quick_begin) / CLOCKS_PER_SEC;
   if(idx!=-1){
    printf("Linear Search Sorted array: b[%d] = %d\n",idx,last_element);
   }
   else{
      printf("%d Element not found \n",last_element); 
   }
 
   printf("main - search took %f: seconds \n\n\n",total_exec_time);
   


  //BINARY SEARCH
  clock_t binary_begin = clock();

  int binaryidx = binary_search(arr,0,MAX_ARR-1,last_element);
 
  clock_t binary_end = clock();
   total_exec_time += (double)(binary_begin - binary_begin) / CLOCKS_PER_SEC;
     if(idx!=-1){
    printf("Binary Search Sorted array: b[%d] = %d\n",binaryidx,last_element);
   }
   else{
      printf("%d Element not found \n",last_element); 
   }
 
   printf("main - search took %f: seconds \n\n\n",total_exec_time);

   

}


/* NAME: selection_sort
PARAMETERS: arr,integer n, integer increasing order or decreasing order. 0 for increaseing, 1 for decreasing
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

void selection_sort(int arr[], int n, int inc_or_dec)
{
    int i, j, min;

    for (i = 0; i < n-1; i++)
    {
        min = i;
        for (j = i+1; j < n; j++)
          {
              if(inc_or_dec=0){
                  if (arr[j] < arr[min])
                   min = j;
              }
              else{
                  if (arr[j] > arr[min])
                  min = j;
              }
              
          }
        swap(&arr[min], &arr[i]);
    }
}

/* NAME: selection_sort
PARAMETERS: pointer x, pointer y
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

/* NAME: quick_sort
PARAMETERS: arr, integer start, integer end
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

void quick_sort(int arr[],int start,int end){
   int i, j, pivot, temp;

   if(start<end){
      pivot=start;
      i=start;
      j=end;

      while(i<j){
         while(arr[i]<=arr[pivot]&&i<end)
           {
                i++;
           }
         while(arr[j]>arr[pivot])
           {
                j--;
           }
         if(i<j){
            temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
         }
      }

      temp=arr[pivot];
      arr[pivot]=arr[j];
      arr[j]=temp;
      quick_sort(arr,start,j-1);
      quick_sort(arr,j+1,end);

   }
}

/* NAME: linear_search
PARAMETERS: arr, integer element
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

 int linear_search(int arr[], int element)
{
    int i;
    for (i = 0; i < MAX_ARR; i++)
        if (arr[i] == element)
            {
                return i;
            }
    return -1;
}


/* NAME: binary_search
PARAMETERS: arr, integer left,integer right,integer element
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

int binary_search(int arr[], int l, int r, int element)
{
    if (r >= l) {
        int mid = l + (r - l) / 2;
 
        if (arr[mid] == element)
            {
                return mid;
                }

        if (arr[mid] > element)
           {
                return binary_search(arr, l, mid - 1, element);
           }

        return binary_search(arr, mid + 1, r, element);
    }

    return -1;
}




/*

h) i.

Rahul Teja Gorantala(rgoranta@ttu.edu) 

 -------------------
   void selection_sort(int arr[], int n, int inc_or_dec)                                 - designed/implemented/modified
   int linear_search(int arr[], int element)                                             - designed/implemented/modified
   main()                                                                                - modified
   void swap(int *x, int *y)                                                             - designed/implemented/modified


Gourav Singla(gsingla@ttu.edu) 
  --------------------------
  void quick_sort(int arr[],int start,int end)                                      -designed/implemented/modified
  int binary_search(int arr[], int l, int r, int element)                           -designed/implemented/modified
  main()                                                                             -designed/implemented
  

h)  ii. 1. sorting arrays with random values                                                           – passed
        2. sorting arrays in increasing or decreasing order                                            – passed
        3. searching for values at the front, middle, and end of the sorted arrays                     – passed                           – passed
        4.searching for values that are not in the arrays                                              – passed   
                                                                    
        


 h) iii. 1. Selection sort will take more steps for already sorted array. It will take more than quick sort. 
         2. Quick sort will take more or less steps based upon choosing pivot. If choose first element as pivot
         in already sorted array, then it will take more steps. Choosing the middle or random is  better.
         3. The starting point can be started from middle. It will then take O(n/2).
         4. space complexity for, selection Sort is O(1), Quick Sort is O(log n), linear search O(1), Binary search O(1) 
 
 */

