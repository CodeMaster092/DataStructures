/*
AUTHOR: Gourav Singla , Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: To read the numbers from n files and store them and merge them in accending order. 
FOR: CS 5401 Data Structures Section 501
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TOTAL_FILES 4
#define SIZE 21

typedef struct data
{
    int val;
    int file_number;

} data;

typedef struct heap
{
    struct data *arr[SIZE];
    int size;

} heap;

int main()
{
    int count = 0;
    FILE *inputFile[TOTAL_FILES];
    FILE *file_one, *outPutFile;
    int i;
    int val1;
    int val2;
    heap hp;
    outPutFile = fopen("merged.txt", "w");

    for (i = 1; i <= TOTAL_FILES; i++)
    {
        char filename[100];
        sprintf(filename, "%d.txt", i);
        inputFile[i] = fopen(filename, "r");
        if (inputFile[i] == NULL)
                continue;

        while (fscanf(inputFile[i], "%d", &val1) != EOF)
        {
            insert(&hp, val1, count, i);
            count++;
        }
    }

    sort(&hp);
    printSortedHeap(&hp, outPutFile);
}

/* NAME: insert
PARAMETERS: root, val, count, file number
PURPOSE: This function pushes the data and the file number into the heap
POSTCONDITION: NA.
*/
void insert(heap *h, int val, int count, int fileno)
{
    data *element;
    data *parentElement;
    int parentidx;
    int lastElementIdx;
    data *temp = (data *)malloc(sizeof(data));
    temp->val = val;
    temp->file_number = fileno;

    if (count == 0)
    {

        h->arr[count] = temp;
        h->size = 1;
    }
    else
    {

        h->arr[count] = temp;
        h->size = h->size + 1;

        lastElementIdx = count;

        while (lastElementIdx > 0)
        {
            element = h->arr[lastElementIdx];
            parentidx = getParent(lastElementIdx);

            parentElement = h->arr[parentidx];

            if (element->val < parentElement->val)
            {

                h->arr[parentidx] = element;
                h->arr[lastElementIdx] = parentElement;
                lastElementIdx = parentidx;
            }
            break;
        }
    }
}

/* NAME: swap
PARAMETERS: element1 , element2
PURPOSE: This function swaps the given two elements
POSTCONDITION: NA.
*/
void swap(int *element1, int *element2)
{
    int temp = *element1;
    *element1 = *element2;
    *element2 = temp;
}

/* NAME: sort
PARAMETERS: root pointer
PURPOSE: This function sorts the given heap
POSTCONDITION: NA.
*/
void sort(heap *hp)
{
    int n = hp->size;
    int i, j;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (hp->arr[j]->val > hp->arr[j + 1]->val)

                swap(&hp->arr[j], &hp->arr[j + 1]);
        }
    }
}

/* NAME: printSortedHeap
PARAMETERS: root pointer, output file
PURPOSE: This function prints the heap into the given  text file
POSTCONDITION: NA.
*/
void printSortedHeap(heap *hp, FILE *outPutFile)
{
    int size = hp->size;
    int i;
    for (i = 0; i < size; i++)
    {
        printf("%d in file no. %d\n", hp->arr[i]->val,hp->arr[i]->file_number);
        fprintf(outPutFile, "%d\n", hp->arr[i]->val);
    }

    printf("\n");
}

/* NAME: getParent
PARAMETERS: present index
PURPOSE: This function gets the parent of the index passed
POSTCONDITION: NA.
*/

int getParent(int n)
{
    if (n == 0)
    {
        return 0;
    }
    int parent = (n - 1) / 2;

    return parent;
}


/*
f) i.

Rahul Teja Gorantala(rgoranta@ttu.edu)
 ---------------------------
   int getParent(int n)                                                                  - designed/implemented/modified
   void printSortedHeap(heap *hp, FILE *outPutFile)                                      - designed/implemented/modified
   int main()                                                                            - designed/implemented/modified


Gourav Singla(gsingla@ttu.edu)
  --------------------------
  void swap(int *element1, int *element2)                                                - designed/implemented/modified
  void insert(heap *h, int val, int count, int fileno)                                   - designed/implemented/modified
  void sort(heap *hp)                                                                    - designed/implemented/modified
  created 1.txt, 2.txt, 4.txt


f)  ii.
        1. 1.txt, 2.txt, merged.txt built                                         � passed/failed
        2. 3<=n<=12 files of sorted integers, merged.txt built                    � passed/failed
        3. one of the m.txt files of sorted integers is empty, merged.txt built   � passed/failed
        4. one of the m.txt files of sorted integers is missing, merged.txt built � passed/failed


 f) iii. 1. O(nlogm)
         2. O(n)
         3. Merge sort works by dividing the list in sub-list until, it list length is 1.
            Then it starts merging them in order. Similarly, merge sort can be implemented in 
            this program to merge the m elemenets of n files.

 */
