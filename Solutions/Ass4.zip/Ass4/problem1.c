#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

struct Node {
    char data;
    struct Node* next;
};

void push(struct Node** top_Node, char new_data);
int pop(struct Node** top_Node);

int MatchPair(char char1, char char2)
{
    if ((char1 == '(' && char2 == ')') || (char1 == '{' && char2 == '}') || (char1 == '[' && char2 == ']'))
        return 1;
    else
        return 0;
}

int BracketsBalance(char character[])
{
    int i = 0, output = 0;
    struct Node* stack = NULL;
    struct Node* stack1 = NULL;
    bool equalsind = false, alphaind = false, First = true, First1 =  true;

    while (character[i])
    {
        if (isalpha(character[i])!= 0 && First)
        {
            alphaind = true;
            First    = false;
        }
        if (character[i] != ' '){
            if (stack1 == NULL && character[i] == '=') {
                return 1;
            }
            if (character[i] == '=' && First1)
            {
                equalsind = true;
                First1    = false;
            }
            push(&stack1, character[i]);
        }

        if (character[i] == '{' || character[i] == '(' || character[i] == '[')
            push(&stack, character[i]);

        if (character[i] == '}' || character[i] == ')'
            || character[i] == ']') {

            if (stack == NULL) {
                output = 3;
            }
            else if (!MatchPair(pop(&stack), character[i]))
            {
                output = 3;
            }
        }
        i++;
    }

    if (alphaind && !equalsind)
        return 2;
    if (output == 3)
        return 3;

    if (!alphaind && !equalsind)
        return 1;

    if (stack == NULL)
        output = 0;
    else
        output = 3;

    return output;
}

int main()
{
    char scan_word[128];
    FILE *readingFile;

    readingFile = fopen("C:\\Users\\P\\CLionProjects\\untitled7\\equations.txt", "r");

    if (readingFile == NULL)
    {
        printf("File not found");
        return 0;
    }

    while( EOF != fscanf(readingFile, "%[^\n]\n", scan_word))
    {
        printf("***ERROR ID %i on %s\n",BracketsBalance(scan_word) ,scan_word);
    }

return 0;
}

void push(struct Node** top_Node, char new_data)
{
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));

    if (new_node == NULL)
    {
        printf("Stack is empty");
        exit(0);
    }
    new_node->data = new_data;
    new_node->next = (*top_Node);
    (*top_Node) = new_node;
}


int pop(struct Node** top_Node)
{
    char temp;
    struct Node* top;

    if (*top_Node != NULL) {
        top = *top_Node;
        temp = top->data;
        *top_Node = top->next;
        free(top);
        return temp;
    }
    else {
        printf("Stack is empty");
        exit(0);
    }
}

