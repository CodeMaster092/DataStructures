#include <stdio.h> 
void fun1(double *smp, double *lgp); 
/*
AUTHOR: Rahul Teja Gorantala	
FILENAME: problem1.c
SPECIFICATION: Calls fun1 function 3 times and displays the arguments passed in ascending order .
FOR: CS 5401 Data Structures Section 501
*/

int main (void) 
{ 
	double num1, num2,num3; 
	printf("Enter 3 numbers separated by blanks>");
	scanf(" %lf %lf %lf", &num1, &num2, &num3);
	fun1(&num1,&num2);	
	fun1(&num1,&num3);
	fun1(&num2,&num3); 
	printf("The numbers are : %.2f  %.2f %.2f \n", num1, num2, num3);
	return (0); 
}


/* NAME: fun1
PARAMETERS: *smp , Reference to input integer ; *lgp , Reference to input integer
PURPOSE: The function computes the average of the list of numbers given as input
PRECONDITION: No
POSTCONDITION: No
*/

void fun1 (double *smp, double *lgp) 
{ 
	double temp; 
	if (*smp > *lgp) 
	{ 
		temp=*smp; 
		*smp=*lgp; 
		*lgp=temp; 
	} 
}


// 1.b this program for any given 3 values, outputs the values num1,num2,num3 in ascending order if the values are passed by reference.
// 1.c If the values are passed by value then there is no change in the values of num1, num2, num3 as called function creates copy of arguments passed to it and there is no change to the input arguments.