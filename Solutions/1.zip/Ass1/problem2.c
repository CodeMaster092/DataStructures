#include <stdio.h>
void linear_regression();
/*AUTHOR: Rahul Teja Gorantala
FILENAME : problem2.c
SPECIFICATION : Data in the input file regarding altitude and ozone-mix-ratio is present .  this should be loaded into the memory
                and using least squares technique, a linear model should be created .
FOR : CS 5401 Data Structures Section 501*/
int main()
{  
	linear_regression();
	return(0);
}


/* NAME: linear_regression
PARAMETERS: No
PURPOSE: The function reads the input file and calculates the slope(altitude) and Intercept(ozone-mix-ratio) to generate a linear model. 
PRECONDITION: No
POSTCONDITION: No
*/
void linear_regression()
{
	FILE* fp;
	double x, y, z;  
	int ch, ind = 0, i = 0; 
	double altitude[4], ozone_mixing_ratio[4], sum_x = 0, sum_y = 0, square_x = 0, xy = 0, slope = 0, cons = 0;
	       
	fp = fopen("zone.txt", "r");
	if (fp != NULL)
	{
		do
		{
			fscanf(fp, "%lf %lf %lf", &x, &y, &z);
			altitude[ind] = y;
			ozone_mixing_ratio[ind] = z;
			ind++;
			ch = fgetc(fp);
		} while (ch != EOF);

		for (i = 0; i < ind; i++)
		{
			sum_x += altitude[i];
			sum_y += ozone_mixing_ratio[i];
			square_x += altitude[i] * altitude[i];
			xy += altitude[i] * ozone_mixing_ratio[i];
		}

		slope = ((sum_x * sum_y) - (i * xy)) / ((sum_x * sum_x) - (i * square_x));
		cons = ((sum_x * xy) - (square_x * sum_y)) / ((sum_x * sum_x) - (i * square_x));
		printf("Range of altitudes in km : %lf to %lf ", altitude[0], altitude[i - 1]);  // 2.e
		printf("\nLinear Model : ozone-mix-ratio = %lf * altitude + %lf", slope, cons);

	}

}

/* 2.f.i.1)   142 bytes is the memory needed to store the data
   2.f.i.2)   An array can be used to store the values from the input file, this solution can also be done without the use of array.

   2.f.ii.1) O(n)
   2.f.ii.2) as f(n) is n, the nearest g(n) will be n and the constant c is 1. therefore according to the definition of Big O, f(n) <= C * g(n).
             as c = 1, therefore f(n) <= O(g(n))
   2.f.ii.3) if f(n) = 3n2 and g(n) = n2 , then according to the definition of Big O, f(n) <= C * g(n)
             3n2 <= C * n2
			 therefore for C = 3, 3n2 <= O(n2)
*/
