#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void add(char *,int);
void printLinkedList(FILE *p);
void printListUndeleted(FILE *p);
void update(char *s);
void count(FILE *p);
void countUndeletedWords(FILE *p);
void deleteNode(char *deleteWord);
char *LowerCase(char *str, size_t len);
int search(char *word);

typedef struct Node
{
    char word[1024];
    int NoOfOccurances;
    struct Node *next;
    struct Node *prev;
} Node;
void Sort(struct Node *start);
void swapping(struct Node *a, struct Node *b);

Node *start = NULL;
Node *prev = NULL;

/*
AUTHOR: Gourav Singla , Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: To read a text file and find unique words and no of occurances of                      unique words.
               To read a stopwords file and then remove the stopwords from the unique words list and move the changes to a new text file.
FOR: CS 5401 Data Structures Section 501
*/
int main()
{
    char scan_word[128];
    FILE *readingFile,*wrtingFile,*readStopFile,*writeStopWord;

    readingFile = fopen("text.txt", "r");
    readStopFile = fopen("stopwords.txt", "r");
    wrtingFile = fopen("concordance.txt","w");
    writeStopWord = fopen("concordance_wo_stop_words.txt","w");

    if (readingFile == NULL || readStopFile==NULL || wrtingFile==NULL)
    {
        printf("File not found");
        return 0;
    }


    while( fscanf(readingFile, "%s", scan_word) != EOF )
    {
        int t = search(&scan_word);
        if(t>0)
        {
            update(&scan_word);
        }
        else
        {
            add(&scan_word,1);
        }
    }
    count(wrtingFile);
    printLinkedList(wrtingFile);

    while( fscanf(readStopFile, "%s", scan_word) != EOF )
    {
        deleteNode(&scan_word);
    }
    countUndeletedWords(writeStopWord);
    printListUndeleted(writeStopWord);
    return 0;
}
/* NAME: add
PARAMETERS: *data - reference to the word to be added to list, time - 1
PURPOSE: This function adds the given data to the linked list.
PRECONDITION: NA
POSTCONDITION: NA
*/
void add(char *data,int time)
{
    Node *temp;
    temp = (Node *)malloc(sizeof(Node));
    size_t len2 = strlen(data);
    strcpy(temp->word, LowerCase(data,len2));
    temp->NoOfOccurances = time;
    temp->next = NULL;
    temp->prev=NULL;
    if(start == NULL)
    {
        start = temp;
    }
    else
    {
        Node *new_temp;
        new_temp = start;

        while (new_temp->next != NULL)
        {
            new_temp = new_temp->next;
        }
        new_temp->next = temp;
        temp->prev = new_temp;
    }
}
/* NAME: printLinkedList
PARAMETERS: *p - File in which the unique words are to be printed
PURPOSE: This function prints the linked list data to the given file .
PRECONDITION: NA
POSTCONDITION: NA
*/
void printLinkedList(FILE *p)
{

    Node *current_Node = start;

    while ( current_Node != NULL)
    {
        fprintf(p, "%s %d\n",current_Node->word,current_Node->NoOfOccurances);
        current_Node = current_Node->next;

    }
}
/* NAME: printListUndeleted
PARAMETERS: *p - File in which the unique words are to be printed
PURPOSE: This function prints the linked list data to the given file .
PRECONDITION: NA
POSTCONDITION: NA
*/
void printListUndeleted(FILE *p)
{

    Node *current_Node = start;

    while ( current_Node != NULL)
    {
        fprintf(p, "%s %d\n",current_Node->word,current_Node->NoOfOccurances);
        current_Node = current_Node->next;

    }
}
/* NAME: update
PARAMETERS: *s - string to update the NoOfOccurances in the list.
PURPOSE: This function prints the linked list data to the given file .
PRECONDITION: NA
POSTCONDITION: NA
*/
void update(char *s){

    Node *current_Node = start;
    size_t len2 = strlen(s);
    while ( current_Node != NULL)
    {
        if(strncmp(current_Node->word,LowerCase(s,len2),15)==0){

            current_Node->NoOfOccurances=current_Node->NoOfOccurances+1;
        }
        current_Node = current_Node->next;

    }
}
/* NAME: count
PARAMETERS: *p - File in which the unique words are to be printed.
PURPOSE: This function prints the Total Unique words to the given file .
PRECONDITION: NA
POSTCONDITION: NA
*/
void count(FILE *p)
{
    int count_words = 0;
    Node *current_Node = start;
    while ( current_Node != NULL)
    {
        count_words++;
        current_Node = current_Node->next;

    }
    fprintf(p, "%s%d\n", "TOTAL UNIQUE WORDS ARE ",count_words);

}
/* NAME: countUndeletedWords
PARAMETERS: *p - File in which the unique words are to be printed.
PURPOSE: This function prints the Total Unique words after removing stopwords to the given file .
PRECONDITION: NA
POSTCONDITION: NA
*/
void countUndeletedWords(FILE *p)
{
    int count_words = 0;
    Node *current_Node = start;
    while ( current_Node != NULL)
    {
        count_words++;
        current_Node = current_Node->next;

    }
    fprintf(p, "%s%d\n", "TOTAL UNIQUE WORDS ARE ",count_words);
}
/* NAME: search
PARAMETERS: *word - word pointer to be sreached in the linked list.
PURPOSE: This function searches the given word in the LinkedList and returns the count .
PRECONDITION: NA
POSTCONDITION: NA
*/
int search(char *word){

    int total=0;
    size_t len2 = strlen(word);
    Node *current_Node = start;
    while ( current_Node != NULL)
    {

        if(strncmp(current_Node->word, LowerCase(word,len2), 15)==0){

            total++;

        }
        current_Node = current_Node->next;

    }
    return total;

}
/* NAME: deleteNode
PARAMETERS: *deleteWord - word pointer to be deleted from the linked list.
PURPOSE: This function searches the given word in the LinkedList and deletes it .
PRECONDITION: NA
POSTCONDITION: NA
*/
void deleteNode(char *deleteWord){
    Node *current_Node = start;
    Node *prev_Node = NULL;

    while ( current_Node != NULL)
    {

        if(strncmp(current_Node->word,deleteWord,15)==0){

            if(start==current_Node){

                start = current_Node->next;
                current_Node->next=NULL;
            }
            else{

                prev_Node = current_Node->prev;
                prev_Node->next = current_Node->next;
            }
            free(current_Node);
        }
        current_Node = current_Node->next;

    }
}

/* NAME: *LowerCase
PARAMETERS: *str - string len - length.
PURPOSE: This function converts upper case string to lower case string .
PRECONDITION: NA
POSTCONDITION: NA
*/
char *LowerCase(char *string, size_t length)
{
    char *str = calloc(length+1, sizeof(char));

    for (size_t i = 0; i < length; ++i)
    {
        str[i] = tolower((unsigned char)string[i]);
    }
    return str;
}

/* NAME: Sort
PARAMETERS: *Start , starting Node of list
PURPOSE: This function sorts the linked list .
PRECONDITION: NA
POSTCONDITION: NA
*/
void Sort(struct Node *start)
{
    int temp, i;
    struct Node *strt;
    struct Node *tempptr = NULL;

    if (start == NULL)
        return;

    do
    {
        temp = 0;
        strt = start;

        while (strt->next != tempptr)
        {
            if (strncmp(strt->word, strt->next->word, 128) > 0)
            {
                swapping(strt, strt->next);
                temp = 1;
            }
            strt = strt->next;
        }
        tempptr = strt;
    }
    while (temp);
}
/* NAME: swapping
PARAMETERS: *node1 , *node2
PURPOSE: This function swaps the given data .
PRECONDITION: NA
POSTCONDITION: NA
*/
void swapping(struct Node *node1, struct Node *node2)
{
    char temp[1024];
    strcpy(temp, node1->word);
    strcpy(node1->word,node2->word);
    strcpy(node2->word,temp);
}


/*
e) i.

  Gourav Singla(gsingla@ttu.edu)
  -------------------
  void deleteNode(char *deleteWord);    - designed/implemented/modified
  searchList(char *word);               - designed/implemented/modified
  void count(FILE *p) ;                 - designed/implemented/modified
  void add(char *data,int time) ;       - designed/implemented
  void printList(FILE *p);              - designed/implemented/modified
  void printListUndeleted(FILE *p);     - designed/implemented/modified
  int main();                           - designed/implemented/modified


  Rahul Teja Gorantala(rgoranta@ttu.edu)
  --------------------------
  char *LowerCase(char *string, size_t length); - designed/implemented/modified
  created text.txt and stopwords.txt for test case 1, 2, 3, 4, 5.
  void update(char *s) ;                - designed/implemented/modified
  void countUndeletedWords(FILE *p);    - designed/implemented/modified
  void swapping(struct Node *node1, struct Node *node2); designed/implemented/modified
  void Sort(struct Node *start);          - designed/implemented/modified
  void add(char *data,int time) ;        - modified

e)  ii. 1.Example text1.txt and stopwords1.txt                   – passed
        2. text2.txt with one word and empty stopwords2.txt      – passed
        3. text3_one_stop_word.txt with one stop word and stopwords3.txt with that stop word                                                     – passed
        4. empty text_empty.txt and nonempty stopwords4.txt      – passed
        5. text5_>500.txt with > 500 total words and stopwords5.txt with > 10 total words  – passed
        6. text6_>1000.txt with > 1000 total words and stopwords5.txt with > 10 total words  – passed


    iii 1. worst case of inserting n strings in an ordered linked list is when all        the strings are alphabetially greater than the last value in the linked list.
        for example, if a linked list has three nodes, "air" "ball" and "cat" then any string which is alpabetically greater than cat (like "dog" is the worst case for an ordered single linked list.
        2. O(n)
        3. O(n)

        */
