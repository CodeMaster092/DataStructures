/*
AUTHOR: Gourav Singla , Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: To read and write the number of unique words in text file and store them in a tree.
FOR: CS 5401 Data Structures Section 501
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void insert_in_tree(char *, int );
void update_tree(char *);
int countTree();
int search_in_tree(char *);
int get_height();


typedef struct Node
{
    char word[1024];
    int totalRepeats;
    struct Node *left;
    struct Node *right;
} Node;
Node *root = NULL;


/* NAME: insert_in_tree
PARAMETERS: character,int
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
void insert_in_tree(char *data, int time)
{

    Node *temp;

    temp = (Node *)malloc(sizeof(Node));
    size_t len2 = strlen(data);
    strcpy(temp->word, data);
    temp->totalRepeats = time;
    temp->left = NULL;
    temp->right = NULL;
    Node *parent;
    if (root == NULL)
    {
        root = temp;
    }

    else
    {
        Node *current;
        current = root;
        parent = NULL;

        while (1)
        {
            parent = current;
            if (strcmp(data, parent->word) <= 0)
            {
                current = current->left;

                if (current == NULL)
                {
                    parent->left = temp;

                    return;
                }
            }
            else if (strcmp(data, parent->word) >= 0)
            {

                current = current->right;
                if (current == NULL)
                {
                    parent->right = temp;

                    return;
                }
            }
        }
    }
}

/* NAME: update_tree
PARAMETERS: character
PURPOSE: This function update the number of times word found in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
void update_tree(char *s)
{

    Node *current_Node = root;

    while (current_Node != NULL)
    {

        if (strncmp(current_Node->word, s, 15) == 0)
        {

            current_Node->totalRepeats = current_Node->totalRepeats + 1;
            return;
        }
        else if (strncmp(s, current_Node->word, 15) < 0)
        {
            current_Node = current_Node->left;
        }
        else if (strncmp(s, current_Node->word, 15) > 0)
        {
            current_Node = current_Node->right;
        }
    }
}


/* NAME: countTree
PARAMETERS: struct *
PURPOSE: This function returns the total number of nodes in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
int countTree(Node *rootPtr)
{
    int x = 1;

    if (rootPtr == NULL)
    {
        return 0;
    }

    else
    {
        x += countTree(rootPtr->left);
        x += countTree(rootPtr->right);
        return x;
    }
}


/* NAME: search_in_tree
PARAMETERS: char
PURPOSE: This function search the word in in tree and returns number of times word repeated. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
int search_in_tree(char *word)
{

   
    Node *current_Node = root;
    while (current_Node != NULL)
    {

        if (strncmp(current_Node->word, word, 15) == 0)
        {

            return current_Node->totalRepeats;
        }
        else if (strncmp(word, current_Node->word, 15) < 0)
        {

            current_Node = current_Node->left;
        }
        else if (strncmp(word, current_Node->word, 15) > 0)
        {

            current_Node = current_Node->right;
        }
    }
    return 0;
}


/* NAME: traverse_tree
PARAMETERS: struct,FILE
PURPOSE: This function traverse the whole tree in-order or accending. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
void traverse_tree(Node *n, FILE *p)

{

    if (n == 0)

        return;

    traverse_tree(n->left, p);

    fprintf(p, "%s %d\n", n->word, n->totalRepeats);

    traverse_tree(n->right, p);
}


/* NAME: get_height
PARAMETERS: struct
PURPOSE: This function returns the height of tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/
int get_height(Node *root)
{

    if (!root)
        return 0;
    else
    {
        int left_height = get_height(root->left);
        int right_height = get_height(root->right);
        if (left_height >= right_height)
            return left_height + 1;
        else
            return right_height + 1;
    }
}

int main()
{
    char scan_word[128];
    char toFindWord[] = "concordance";
    char toFindWordTwo[] = "Gourav";

    FILE *readingFile, *wrtingFile, *readStopFile, *writeStopWord;
    readingFile = fopen("text.txt", "r");
    wrtingFile = fopen("concordance.txt", "w");
    while (fscanf(readingFile, "%s", scan_word) != EOF)
    {

        int t = search_in_tree(&scan_word);
        if (t > 0)
        {

            update_tree(&scan_word);
        }
        else
        {

            insert_in_tree(&scan_word, 1);
        }
    }
    fprintf(wrtingFile, "%s%d\n", "TOTAL UNIQUE WORDS ARE ", countTree(root));
    traverse_tree(root, wrtingFile);
    printf("Tree Check\n");
    printf("Tree Height : %d\n", get_height(root));
    printf("Tree Size : %d\n", countTree(root));

    if(search_in_tree(toFindWord)>0){
    printf("%s Found and has frequency %d\n", toFindWord,search_in_tree(toFindWord));
    }
    else{
        printf("%s Not Found \n");
    }
   if(search_in_tree(toFindWordTwo)>0){
    printf("%s Found and has frequency %d\n", toFindWordTwo,search_in_tree(toFindWordTwo));
    }
    else{
        printf("%s Not Found \n",toFindWordTwo);
    }

    return 0;
}

/*
g) i.

Gourav Singla(gsingla@ttu.edu) 

 -------------------
  void insert_in_tree(char *, int );          - designed/implemented/modified
  void update_tree(char *);                   - designed/implemented/modified
  int main();                                 - designed/implemented/modified
  created text.txt, concordance.txt                          


Rahul Teja Gorantala(rgoranta@ttu.edu) 
  --------------------------
  int search_in_tree(char *);                -designed/implemented/modified
  int get_height();                          -designed/implemented/modified
  int countTree();                           -designed/implemented/modified  
  created equation_test1.txt,equation_test2.txt,equation_test3.txt,equation_test4.txt for test case 1, 2, 3, 4.
  

g)  ii. 1. text.txt                                                                   – passed
        2. empty_text.txt                                                             – passed
        3. large_text.txt >500 words                                                  – passed
        4. empty equation_test1.txt                                                   – passed
        5. one_word.txt                                                               – passed
        


 g) iii. 1. Best case is when all the words are exact same. At that time, the tree will not have left or right 
            and therefore no need to tranverse the tree. 
         2. O(1). Because we are inserting one word again and again.  
         3. O(n)
         4. Minimum height should be 3.    
 
 */
