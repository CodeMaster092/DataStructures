/*
AUTHOR: Gourav Singla , Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: To read and write the number of unique words in text file and store them in 2-3 tree.
FOR: CS 5401 Data Structures Section 501
*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define KEYS 2                   /* max number of keys in a 2-3 tree node */

typedef struct data_node {
    int Occurances;
    char value[128];
} data_t;

typedef struct node {              /* 2-3 tree node */
    int num_keys;                    /* number of keys in the data array */
    data_t data[KEYS+1];             /* data array */
    struct node *tree_p[KEYS+1+1];   /* pointer array */
} tree_t;

tree_t * search_23tree (tree_t *, char[128]);  /* recursive search function to find an element in a 2-3 tree */
tree_t * create_node ();                 /* creates and initializes an empty 2-3 tree node */
void insert (tree_t **root, data_t val);   /* recursive helper function for recur_insert function */
void recur_insert (tree_t **root, data_t val, int *split, data_t *mid, tree_t **newp); /* recursively insert a key into a 2-3 tree */
void recur_print (tree_t *tree, int level, FILE *WritingFile);   /* print the bst recursively and addresses */
char * tolowercase(char s[128]);  /* convert UpperCase to Lowercase */
int height(tree_t *tree, int level);   /* Recursive function to find the height of a 2-3 tree*/
void size(tree_t *tree, int level, int*); /* Recursive function to find the size of a 2-3 tree*/


int main(void) {
    char scan_word[128];
    char toFindWord[] = "concordance";
    int NoOfNodes = 0, i =0;
    tree_t *search = NULL;

    FILE *readingFile, *wrtingFile, *readStopFile, *writeStopWord;
    readingFile = fopen("text.txt", "r");
    wrtingFile = fopen("concordance.txt", "w");
    tree_t *root = NULL;
    char *scan_word1;
    data_t data1 = {1,""};
    while (fscanf(readingFile, "%s", scan_word) != EOF)
    {
        scan_word1 = tolowercase(scan_word);
        strncpy(data1.value, scan_word1, 128);
        insert(&root, data1);
    }

    size(root, 0, &NoOfNodes);
    fprintf(wrtingFile,"There are %i distinct words in the text file:\n", NoOfNodes);
    recur_print(root, 0,wrtingFile);
    printf("Tree Check:\n");
    printf("Tree Height : %i\n", height(root, 0));
    printf("Tree Size : %i\n", NoOfNodes);
    search = search_23tree (root, toFindWord);
    if(search != NULL){
        for (i = search->num_keys; i >= 0; i--) {
            if(strncmp(search->data[i].value, toFindWord, 64) == 0)
                printf("%s is found and has a frequency of %i",toFindWord, search->data[i].Occurances);
        }
    }
    else
        printf("%s is not found", toFindWord);

}
/* NAME: insert
PARAMETERS: root,struct data_t
PURPOSE: This function puts the data or word in tree. 
PRECONDITION: NA
POSTCONDITION: NA.
*/

void insert (tree_t **root, data_t val) {
    data_t mid;
    int split;
    tree_t *newp;
    tree_t *new1;
    new1 = *root;
    tree_t *ptr;
    int i ;
    if (*root == NULL) {
        newp = create_node();
        newp->data[0] = val;
        newp->num_keys = 1;
        *root = newp;
    }
        
    else {

        if (search_23tree(*root,val.value) == NULL) {
            split = 0;
            recur_insert (root,val,&split,&mid,&ptr);
            if (split) {
                newp = create_node();
                newp->data[0] = mid;
                newp->tree_p[0] = *root;
                newp->tree_p[1] = ptr;
                newp->num_keys = 1;
                *root = newp;
            }
        }
        else{
            new1 = search_23tree(*root,val.value);
            for (i = new1->num_keys; i >= 0; i--) {
                if(strncmp(new1->data[i].value, val.value, 128) == 0)
                    new1->data[i].Occurances = new1->data[i].Occurances + 1;
            }
        }
    }
}

/* NAME: recur_insert
PARAMETERS: root,struct data_t,pointer, struct data_t, struct data_t pointer, struct tree_t
PURPOSE: recursively insert a key into a 2-3 tree 
PRECONDITION: NA
POSTCONDITION: NA.
*/

void recur_insert (tree_t **root, data_t val, int *split, data_t *mid, tree_t **newp) {
    int i,j;
    tree_t *np;
    if ((*root)->tree_p[0] == NULL) {    // insert val in leaf node
        for (i = (*root)->num_keys; i > 0 && strncmp(val.value, (*root)->data[i-1].value, 128) < 0; i--) {
            (*root)->data[i] = (*root)->data[i-1];
            (*root)->tree_p[i+1] = (*root)->tree_p[i];
        }
        (*root)->data[i] = val;
        (*root)->tree_p[i+1] = NULL;
        (*root)->num_keys++;
        if ((*root)->num_keys == KEYS+1) {     // split leaf node
            *split = 1;
            *newp = create_node ();
            (*newp)->data[0] = (*root)->data[KEYS];
            (*newp)->num_keys = 1;
            *mid = (*root)->data[1];
            (*root)->num_keys = 1;
        }
    }
    else {               // internal node
       // if (DEBUG) printf("recur_insert - internal - before recur - val = %d  (*root)->data[0].key = %d\n",val.key,(*root)->data[0].key);
        // determine which tree_p pointer to traverse
        for (i = 0; i < (*root)->num_keys && strncmp(val.value, (*root)->data[i].value, 128) > 0; i++);
        recur_insert (&((*root)->tree_p[i]), val, split, mid, newp);
        if (*split) {   // a split occurred on the call to recur_insert
            *split = 0;
            // insert *mid and *newp into **root
            for (i = (*root)->num_keys; i > 0 && strncmp(mid->value, (*root)->data[i-1].value, 128) < 0; i--) {
                (*root)->data[i] = (*root)->data[i-1];
                (*root)->tree_p[i+1] = (*root)->tree_p[i];
            }
            (*root)->data[i] = *mid;
            (*root)->tree_p[i+1] = *newp;
            (*root)->num_keys++;
            if ((*root)->num_keys == KEYS+1) {     // split internal node
                *split = 1;
                *newp = create_node ();
                (*newp)->data[0] = (*root)->data[KEYS];
                (*newp)->tree_p[0] = (*root)->tree_p[2];
                (*newp)->tree_p[1] = (*root)->tree_p[3];
                (*newp)->num_keys = 1;
                *mid = (*root)->data[1];
                (*root)->num_keys = 1;
            }
        }
    }
}

/* NAME: create_node
PARAMETERS: n/a
PURPOSE: create_node creates and initializes an empty tree node 
PRECONDITION: NA
POSTCONDITION: NA.
*/


tree_t * create_node () {
    tree_t *newp = (tree_t *) malloc (sizeof(tree_t));
    int i;
    for (i = 0; i < KEYS; i++) {
        newp->data[i].Occurances = 1;
        strcpy(newp->data[i].value, "");
        newp->tree_p[i] = NULL;
    }
    newp->tree_p[i] = NULL;
    newp->num_keys = 0;
    return(newp);
}

/* NAME: search_23tree
PARAMETERS: struct tree_t pointer, char
PURPOSE: search_23tree searches a 2-3 tree recursively and returns a pointer to the node containing num
PRECONDITION: NA
POSTCONDITION: NA.
*/


tree_t * search_23tree (tree_t *root, char value[128]) {
    tree_t *p = NULL;
    char *ptr = value;
    if (root != NULL) {
        int i = 0;
        for (i = 0; i < root->num_keys && strcmp(root->data[i].value, value) < 0; i++);  /* position i with respect to num */
        if (i < root->num_keys && strcmp(root->data[i].value, value) == 0)       /* check for num in root->data[i] */
            p = root;
        else
            p = search_23tree (root->tree_p[i],value);                /* keep searching down root->tree_p[i] */
    }
    return (p);
}


/* NAME: recur_print
PARAMETERS: struct tree_t pointer, int, FILE
PURPOSE: recursive 2-3 tree print with addresses
PRECONDITION: NA
POSTCONDITION: NA.
*/

void recur_print (tree_t *tree, int level, FILE *WritingFile) {
    int i;
    if (tree != NULL) {
        for (i = 0; i < tree->num_keys; i++) fprintf(WritingFile, "%s %d\n", tree->data[i].value, tree->data[i].Occurances);
        for (i = 0; i <= tree->num_keys; i++)
            recur_print (tree->tree_p[i],level+1, WritingFile);
    }
}

/* NAME: height
PARAMETERS: struct tree_t pointer, int
PURPOSE: Recursive function to find the height of a 2-3 tree
PRECONDITION: NA
POSTCONDITION: NA.
*/

int height(tree_t *tree, int level){
    int i, height1;
    if (tree != NULL){
        for (i = 0; i <= tree->num_keys; i++){
            height1 =  height(tree->tree_p[i],level+1);
            return height1+1;
        }
    }
}

/* NAME: size
PARAMETERS: struct tree_t pointer, int, output pointer
PURPOSE: Recursive function to find the size of a 2-3 tree
PRECONDITION: NA
POSTCONDITION: NA.
*/


void size(tree_t *tree, int level, int* output){
    int i;
    if (tree != NULL) {
        for (i = 0; i < level; i++);
        *output = *output + tree->num_keys;
        for (i = 0; i <= tree->num_keys; i++)
            size(tree->tree_p[i], level + 1, output);
    }
}

/* NAME: tolowercase
PARAMETERS: char
PURPOSE: convert char to lowercase
PRECONDITION: NA
POSTCONDITION: NA.
*/

char * tolowercase(char s[128]){
    int i;
    for (i = 0; s[i]!='\0'; i++) {
        if(s[i] >= 'A' && s[i] <= 'Z'){
            s[i] = s[i] + 32;
        }
    }
    return s;
}

/*



g) i.

Rahul Teja Gorantala(rgoranta@ttu.edu) 


 -------------------
   insert (tree_t **root, data_t val)                                                    - designed/implemented/modified
   recur_insert (tree_t **root, data_t val, int *split, data_t *mid, tree_t **newp)      - designed/implemented/modified
   recur_print (tree_t *tree, int level, FILE *WritingFile)                              - designed/implemented/modified
   main()                                                                                - designed/implemented/modified
  created text.txt, concordance.txt                          


Gourav Singla(gsingla@ttu.edu) 
  --------------------------
  create_node ();                                      -designed/implemented/modified
  tolowercase(char s[128])                             -designed/implemented/modified
  height(tree_t *tree, int level);                     -designed/implemented/modified  
  size(tree_t *tree, int level, int*);                -designed/implemented/modified
  created one_word.txt,empty_text.txt,large_text.txt,for test case 2, 3, 4, 5.
  

g)  ii. 1. text.txt                                                                   – passed
        2. empty_text.txt                                                             – passed
        3. large_text.txt >500 words                                                  – passed
        4. empty equation_test1.txt                                                   – passed
        5. one_word.txt                                                               – passed
        


 g) iii. 1. Worst-case will be O(logn). 
         2. Best-case will be O(logn). 

         3. O(n)
         4. Minimum height should be 3.  
 
 */




