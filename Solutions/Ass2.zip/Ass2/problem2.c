#include<stdio.h>
#include<string.h>

int optimum_search(char str[], char substr[]);
int bruteforce_search(char str[], char substr[]);

/*AUTHOR: Rahul Teja Gorantala
FILENAME : problem2.c
SPECIFICATION : This Program searches a substring in the string and returns its position.
FOR : CS 5401 Data Structures Section 501*/


main()
{
	char substr[] = "carro";
	char str[] = "carro carro carro carro";
	
	printf("%i",bruteforce_search(str, substr));
	printf("\n");
	printf("%i", optimum_search(str, substr));
}

/* NAME: optimum_search
PARAMETERS: str string, substr string that needs to be searched
PURPOSE: The Function finds the substring in the string in a optimum method 
PRECONDITION: None
POSTCONDITION: None */

int optimum_search(char str[], char substr[])
{
	char *Match = "no";
	int index = 0, return_ind = 0, i = 0, j = 0;
	while (str[i] != '\0'){
		return_ind = index;
		if (Match == "yes") {
			if (index == 0){
				index = i - 1;
			}
			j++;
		}
		while (substr[j] != '\0'){
			if (str[i] == substr[j]){
				Match = "yes";
			}
			else if (str[i] != substr[j]){
				j = 0;
				index = 0;
				Match = "no";
			}
			break;
		}
		if (substr[j] == '\0'){
			return return_ind;
		}
		i++;
	} return -1;
}

/* NAME: bruteforce_search
PARAMETERS: str string, substr string that needs to be searched
PURPOSE: The Function searches the string with the sub string character by character in a brute force way and returns the postion of the string .
PRECONDITION: None
POSTCONDITION: None */

int bruteforce_search(char str[], char substr[])
{
	char *Match = "no";
	int index = 0, i = 0, j = 0, ind = 0, start_index = 0;
	while (str[i] != '\0'){
		if (str[i] == substr[j]){
			if (Match == "no")
			{
				Match = "yes";
				start_index = i + 1;
			}
			i++;
			j++;
		}
		else if (substr[j] != '\0' && str[i] != substr[j]) {
			if (Match == "yes"){
				 i = start_index;
			}
			else{
				i++;
			}
			Match = "no";
			j = 0;
		}
		else  {
		return start_index;
		}
	} return -1;
}
/*
d. i. for input 
	        char str[] = "carro carro carro carro"";
	  for substr[] = "carro" - answer is 1
	  for substr[] = "carrot" - answer is -1

   ii. 1. when there are m characters in substring and x repetaions of m-1 characters through out the string n characters.
          example: string is "carrocarrocarrocarrot" and substring is "carrot"
		  Time complexity is O(m*n)
       2. example: when there are no repetations of sustring in the string.Time complexity is O(n)

*/

