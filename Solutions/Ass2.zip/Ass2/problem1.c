#include <stdio.h>

#define ROW 6
#define COLOUMN 7

void peak_find(int arr[ROW][COLOUMN]);

/* NAME: peak_find
PARAMETERS: array input 2D array
PURPOSE: The function takes an array as an input and finds the peak.
PRECONDITION: None
POSTCONDITION: None
*/

void peak_find(int array[ROW][COLOUMN])
{
	int counter = 0;
	int peak_arr[ROW][COLOUMN];
	for (int i = 0; i < ROW; i++){
		for (int j = 0; j < COLOUMN; j++){
			if ((i != 0 && j != 0) && (i != ROW - 1 && j != COLOUMN - 1))
			{
				if (array[i][j] > array[i][j - 1] && array[i][j] > array[i - 1][j] && array[i][j] > array[i][j + 1] && array[i][j] > array[i + 1][j]){
					peak_arr[i][j] = array[i][j];
					counter++;
				}
			    else{
					peak_arr[i][j] = NULL;
				}
			}
			else{
					peak_arr[i][j] = NULL;
				}
		}
	}
	printf("%i peaks found at:", counter);
	for (int i = 0; i < ROW; i++){
		for (int j = 0; j < COLOUMN; j++){
			if (peak_arr[i][j] != NULL){
				printf("\nrow %i and column %i", i, j);
			}
		}
	}
	return;
}

/*
AUTHOR: Rahul Teja Gorantala
FILENAME: problem1.c
SPECIFICATION: Finds the Peak from the array and displays the output
FOR: CS 5401 Data Structures Section 501
*/

main()
{
	int i = 0, j = 0;
	int array[ROW][COLOUMN] = { {5039,5127,5238,5259,5248,5310,5299},
								{5150,5392,5410,5401,5320,5820,5321},
								{5290,5560,5490,5421,5530,5831,5210},
								{5110,5429,5430,5411,5459,5630,5319},
								{4920,5129,4921,5821,4722,4921,5129},
								{5023,5129,4822,4872,4794,4862,4245} };
	peak_find(array);

}

/* d) i) 3 peaks found:
		Location at row 2 and column 1
		Location at row 2 and column 5
		Location at row 4 and column 3
	  
	  ii) formula to calculate no of peaks is (rows-2)*(coloumns-2) / 2 and complexity is O(Rows*Colums) 
	  iii) O(Rows*Colums)  */